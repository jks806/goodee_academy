package com.gyesu.kiosk.catcafe.test;

import java.util.ArrayList;
import java.util.Scanner;

public class KioskObj {
	public static ArrayList<Order> basket = new ArrayList<>(); // 주문들
	public static ArrayList<Product> products_drink = new ArrayList<>(); // 상품들
	public static ArrayList<Product> products_dessert = new ArrayList<>(); // 상품들
	public static ArrayList<Product> products_food = new ArrayList<>(); // 상품들
	public static Scanner sc = new Scanner(System.in);
	public static String cmd;

	public static void productLoad() {
		products_drink.add(new Product("커피", 1000)); //// 상품목록 처리 ////
		products_drink.add(new Product("오렌지쥬스", 2000));
		products_drink.add(new Product("콜라", 1500));
		
		products_dessert.add(new Product("마카롱", 2000));
		products_dessert.add(new Product("샌드위치", 3000));
		
		products_food.add(new Product("김밥", 1500));
		products_food.add(new Product("라면", 3000));
	}
}
