package com.gyesu.c.board;

import com.gyesu.c.board.data.Data;
import com.gyesu.c.board.data.Post;
import com.gyesu.c.board.display.Disp;
import com.gyesu.util.Ci;
import com.gyesu.util.Cw;

public class ProcMenuRead {
	static void run() {
		//todo
		//임시
		Cw.wn("읽기");
		String cmd = Ci.r("게시글 번호");
		for(Post p:Data.posts) {
			if(cmd.equals(p.instanceNo+"")) {
				p.infoForRead();
			}
		}		
	}

}
