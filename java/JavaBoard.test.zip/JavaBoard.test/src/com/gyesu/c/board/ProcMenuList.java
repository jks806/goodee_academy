package com.gyesu.c.board;

import com.gyesu.c.board.data.Data;
import com.gyesu.c.board.data.Post;
import com.gyesu.util.Cw;

public class ProcMenuList {
	static void run() {
		Cw.wn("리스트");
		for (Post p : Data.posts) {
			p.infoForList();
		}
	}

}
