package com.gyesu.c.board;

import com.gyesu.c.board.data.Data;
import com.gyesu.c.board.data.Post;
import com.gyesu.util.Ci;
import com.gyesu.util.Cw;

public class ProcMenuUpdate {
	static void run() {
		Cw.wn("수정");
		String cmd = Ci.r("수정할 글 번호");

		for (Post p : Data.posts) {
			if (cmd.equals(p.instanceNo + "")) {
				String content = Ci.rl("수정 할 글내용");
				p.content = content;
				Cw.wn("수정 완료");
			}
		}
	}
}