package com.gyesu.c.board;

import com.gyesu.c.board.data.Data;
import com.gyesu.c.board.data.Post;
import com.gyesu.util.Ci;
import com.gyesu.util.Cw;

public class ProcMenuDel {
	static void run() {
		Cw.wn("삭제");
		String cmd = Ci.r("삭제할 글 번호");
		int tempSearchIndex = 0;
		for (int i = 0; i < Data.posts.size(); i = i + 1) {
			if (cmd.equals(Data.posts.get(i).instanceNo + "")) {
				tempSearchIndex = i;
			}
		}
		Data.posts.remove(tempSearchIndex);
		Cw.wn("남은 게시글 수:" + Data.posts.size());
	}
}