package com.gyesu.c.board;

import com.gyesu.c.board.data.Data;
import com.gyesu.c.board.display.Disp;
import com.gyesu.util.Ci;

public class Board {
	public static final String VERSION = " .TEST_ver"; 
	public static final String TITLE = "게시판 (" + VERSION + ")";

	public void run() {
		Data.loadData();
		Disp.title();
		ProcMenu.run();
	}
}
