package com.gyesu.c.board.display;

import com.gyesu.c.board.Board;
import com.gyesu.util.Cw;

public class Disp {
	public static void title() {
		Cw.line();
		Cw.dot();
		Cw.space(21);
		Cw.w(Board.TITLE);
		Cw.space(21);
		Cw.dot();
		Cw.wn();
		Cw.line();
	}

	public static void menuMain() {
		Cw.w("[1 .글 리스트/2. 글 읽기/3. 글 작성/4. 글 삭제/5. 글 수정/e.종료]");
		Cw.wn();
	}

}
