package com.gyesu.c.board;

import com.gyesu.c.board.display.Disp;
import com.gyesu.util.Ci;
import com.gyesu.util.Cw;

public class ProcMenu {
	static void run() {
		Disp.menuMain();
		loop: while (true) {
			String cmd = Ci.r("명령");
			switch (cmd) {
			case "1": 
				ProcMenuList.run();
				break;
			case "2": 
				ProcMenuRead.run();
				break;
			case "3": 
				ProcMenuWrite.run();
				break;
			case "4": 
				ProcMenuDel.run();
				break;
			case "5": 
				ProcMenuUpdate.run();
				break;
			case "e":
				System.out.println("프로그램 종료");
				break loop;
			default:
				Cw.wn("잘못된 형식의 입력입니다.");
				break;
			}
		}
	}

}
