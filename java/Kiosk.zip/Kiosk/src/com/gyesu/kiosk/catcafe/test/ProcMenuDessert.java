package com.gyesu.kiosk.catcafe.test;

import com.gyesu.util.Cw;

public class ProcMenuDessert {

	public static void run() {

		for (Product p : KioskObj.products_dessert) { // 메뉴출력
			Cw.wn(p.name + " : " + p.price + "원");
		}
		yy: while (true) {
			Cw.wn("[1.마카롱/2.샌드위치/x.이전메뉴로]");
			KioskObj.cmd = KioskObj.sc.next();
			switch (KioskObj.cmd) {
			case "1":
				Cw.wn(KioskObj.products_dessert.get(0).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products_dessert.get(0))); // 오더 추가
				break;
			case "2":
				Cw.wn(KioskObj.products_dessert.get(1).name + " 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products_dessert.get(1))); 
				break;
			case "x":
				Cw.wn("이전 메뉴 이동");
				break yy;
			}
		}
	}
}
