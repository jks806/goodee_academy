package com.gyesu.kiosk.catcafe.test;

import com.gyesu.util.Cw;

public class ProcMenuOptionHotCold {

	public static void run() {
		loop: while (true) {
			Cw.wn("[1.HOT/2.ICE/x.이전메뉴로]");
			KioskObj.cmd = KioskObj.sc.next();
			switch (KioskObj.cmd) {
			case "1":
				Cw.wn("HOT 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products_drink.get(0), 1)); // 오더 추가
				break loop;
			case "2":
				Cw.wn("ICE 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products_drink.get(0), 2)); // 오더 추가
				break loop;
			case "x":
				Cw.wn("이전 메뉴 이동");
				break loop;
			}
		}
	}
}
